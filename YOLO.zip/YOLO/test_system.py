#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统功能测试脚本
用于验证YOLOv8实例分割系统的基本功能
"""

import os
import sys
from pathlib import Path


def test_system_structure():
    """测试系统结构"""
    print("=" * 50)
    print("系统结构测试")
    print("=" * 50)
    
    project_dir = Path(__file__).parent
    
    # 检查必要文件
    required_files = [
        "README.md",
        "train.py", 
        "test_gui.py",
        "requirements.txt",
        "data/README.md",
        "data/data.yaml"
    ]
    
    all_files_exist = True
    for file_path in required_files:
        full_path = project_dir / file_path
        if full_path.exists():
            print(f"[OK] {file_path} 存在")
        else:
            print(f"[ERROR] {file_path} 不存在")
            all_files_exist = False
    
    # 检查必要目录
    required_dirs = [
        "data",
        "model"
    ]
    
    for dir_path in required_dirs:
        full_path = project_dir / dir_path
        if full_path.exists():
            print(f"[OK] {dir_path}/ 目录存在")
        else:
            print(f"[ERROR] {dir_path}/ 目录不存在")
            all_files_exist = False
    
    return all_files_exist


def test_python_environment():
    """测试Python环境"""
    print("\n" + "=" * 50)
    print("Python环境测试")
    print("=" * 50)
    
    try:
        import torch
        print(f"[OK] PyTorch版本: {torch.__version__}")
    except ImportError:
        print("[ERROR] PyTorch未安装")
        return False
    
    try:
        import ultralytics
        print(f"[OK] Ultralytics版本: {ultralytics.__version__}")
    except ImportError:
        print("[ERROR] Ultralytics未安装")
        return False
    
    try:
        import cv2
        print(f"[OK] OpenCV版本: {cv2.__version__}")
    except ImportError:
        print("[ERROR] OpenCV未安装")
        return False
    
    try:
        import yaml
        print(f"[OK] PyYAML已安装")
    except ImportError:
        print("[ERROR] PyYAML未安装")
        return False
    
    try:
        import tkinter
        print(f"[OK] tkinter已安装")
    except ImportError:
        print("[ERROR] tkinter未安装")
        return False
    
    return True


def test_data_structure():
    """测试数据集结构"""
    print("\n" + "=" * 50)
    print("数据集结构测试")
    print("=" * 50)
    
    data_dir = Path(__file__).parent / "data"
    
    # 检查数据集目录结构
    required_data_dirs = [
        "images/train",
        "images/val", 
        "labels/train",
        "labels/val"
    ]
    
    all_dirs_exist = True
    for dir_path in required_data_dirs:
        full_path = data_dir / dir_path
        if full_path.exists():
            print(f"[OK] {dir_path}/ 目录存在")
        else:
            print(f"[WARNING] {dir_path}/ 目录不存在（训练时需要）")
            all_dirs_exist = False
    
    # 检查是否有示例数据
    train_images = list((data_dir / "images" / "train").glob("*"))
    val_images = list((data_dir / "images" / "val").glob("*"))
    
    if train_images:
        print(f"[OK] 训练集有 {len(train_images)} 个图像文件")
    else:
        print("[WARNING] 训练集没有图像文件（训练时需要）")
    
    if val_images:
        print(f"[OK] 验证集有 {len(val_images)} 个图像文件")
    else:
        print("[WARNING] 验证集没有图像文件（训练时需要）")
    
    return all_dirs_exist


def test_model_directory():
    """测试模型目录"""
    print("\n" + "=" * 50)
    print("模型目录测试")
    print("=" * 50)
    
    model_dir = Path(__file__).parent / "model"
    
    if model_dir.exists():
        print(f"[OK] model/ 目录存在")
        
        # 检查是否有模型文件
        model_files = list(model_dir.glob("*.pt")) + list(model_dir.glob("*.onnx"))
        if model_files:
            print(f"[OK] 找到 {len(model_files)} 个模型文件:")
            for model_file in model_files:
                print(f"  - {model_file.name}")
        else:
            print("[WARNING] 没有找到模型文件（训练后会生成）")
    else:
        print("[ERROR] model/ 目录不存在")
        return False
    
    return True


def main():
    """主测试函数"""
    print("YOLOv8实例分割系统功能测试")
    print("=" * 60)
    
    # 运行各项测试
    structure_ok = test_system_structure()
    environment_ok = test_python_environment()
    data_ok = test_data_structure()
    model_ok = test_model_directory()
    
    # 总结
    print("\n" + "=" * 60)
    print("测试总结")
    print("=" * 60)
    
    if structure_ok and environment_ok:
        print("[OK] 系统基本结构完整")
        print("[OK] Python环境配置正确")
        
        if data_ok:
            print("[OK] 数据集结构完整，可以开始训练")
        else:
            print("[WARNING] 数据集结构不完整，请按照data/README.md准备数据")
        
        if model_ok:
            print("[OK] 模型目录正常")
        else:
            print("[WARNING] 模型目录需要创建")
        
        print("\n下一步操作:")
        print("1. 准备数据集（按照data/README.md要求）")
        print("2. 运行训练: python train.py")
        print("3. 测试模型: python test_gui.py")
        
    else:
        print("[ERROR] 系统配置存在问题，请检查:")
        if not structure_ok:
            print("  - 系统文件不完整")
        if not environment_ok:
            print("  - Python依赖包未正确安装")
        
        print("\n解决方法:")
        print("1. 安装依赖: pip install -r requirements.txt")
        print("2. 确保所有必要文件存在")
    
    print("\n测试完成！")


if __name__ == "__main__":
    main()
