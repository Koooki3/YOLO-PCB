# 基于YOLOv8的个人实例分割系统

## 项目概述
本项目实现了一个基于YOLOv8的个人实例分割系统，支持训练、模型保存和测试功能。

## 功能特性
- 自动下载预训练模型（如不存在）
- 支持用户自制数据集
- 完整的训练脚本和结果输出
- 自动保存模型为ONNX格式
- 带GUI的测试界面

## 项目结构
```
D:/PythonProject/
├── data/                    # 数据集目录
│   ├── README.md           # 数据集制作要求
│   └── ...                 # 用户数据集文件
├── model/                  # 模型保存目录
├── train.py               # 训练脚本
├── test_gui.py           # GUI测试脚本
├── requirements.txt       # 依赖包列表
└── README.md             # 项目说明
```

## 使用方法
1. 准备数据集并放置在data文件夹中
2. 运行训练脚本：`python train.py`
3. 使用GUI测试：`python test_gui.py`

## 依赖环境
- Python 3.8+
- PyTorch
- Ultralytics YOLOv8
- OpenCV
- tkinter
- onnx
