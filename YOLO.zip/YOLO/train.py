#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于YOLOv8的个人实例分割系统训练脚本
功能：
1. 自动下载预训练模型（如不存在）
2. 加载用户自制数据集
3. 训练模型并输出完整结果
4. 自动保存模型为ONNX格式
"""

import os
import sys
import yaml
import torch
from ultralytics import YOLO
from pathlib import Path
import shutil
import json
from datetime import datetime


class YOLOv8InstanceSegmentationTrainer:
    def __init__(self):
        self.project_dir = Path(__file__).parent
        self.data_dir = self.project_dir / "data"
        self.model_dir = self.project_dir / "model"
        self.pretrained_model = "yolov8n-seg.pt"  # YOLOv8 nano segmentation model
        
        # 创建必要的目录
        self.model_dir.mkdir(exist_ok=True)
        
        # 训练参数
        self.epochs = 100
        self.imgsz = 640
        self.batch = 16
        self.patience = 10
        
        print("YOLOv8实例分割训练器初始化完成")
        print(f"项目目录: {self.project_dir}")
        print(f"数据目录: {self.data_dir}")
        print(f"模型目录: {self.model_dir}")
    
    def check_data_structure(self):
        """检查数据集结构是否符合要求"""
        print("检查数据集结构...")
        
        required_dirs = [
            self.data_dir / "images" / "train",
            self.data_dir / "images" / "val",
            self.data_dir / "labels" / "train",
            self.data_dir / "labels" / "val"
        ]
        
        for dir_path in required_dirs:
            if not dir_path.exists():
                print(f"错误: 缺少必要目录 {dir_path}")
                return False
        
        # 检查是否有图像文件
        train_images = list((self.data_dir / "images" / "train").glob("*"))
        val_images = list((self.data_dir / "images" / "val").glob("*"))
        
        if len(train_images) == 0:
            print("错误: 训练集没有图像文件")
            return False
        
        if len(val_images) == 0:
            print("错误: 验证集没有图像文件")
            return False
        
        print(f"训练集图像数量: {len(train_images)}")
        print(f"验证集图像数量: {len(val_images)}")
        
        return True
    
    def create_data_yaml(self):
        """创建data.yaml配置文件"""
        print("创建data.yaml配置文件...")
        
        # 自动检测类别数量
        train_labels_dir = self.data_dir / "labels" / "train"
        class_ids = set()
        
        for label_file in train_labels_dir.glob("*.txt"):
            with open(label_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        class_id = int(line.strip().split()[0])
                        class_ids.add(class_id)
        
        nc = len(class_ids)
        names = [f"class_{i}" for i in range(nc)]
        
        data_yaml = {
            'path': str(self.data_dir),
            'train': 'images/train',
            'val': 'images/val',
            'nc': nc,
            'names': names
        }
        
        yaml_path = self.data_dir / "data.yaml"
        with open(yaml_path, 'w', encoding='utf-8') as f:
            yaml.dump(data_yaml, f, default_flow_style=False, allow_unicode=True)
        
        print(f"data.yaml创建完成: {yaml_path}")
        print(f"检测到 {nc} 个类别: {names}")
        
        return yaml_path
    
    def download_pretrained_model(self):
        """下载预训练模型"""
        print("检查预训练模型...")
        
        model_path = self.model_dir / self.pretrained_model
        
        if not model_path.exists():
            print(f"下载预训练模型: {self.pretrained_model}")
            try:
                model = YOLO(self.pretrained_model)
                # 保存到本地
                model.save(model_path)
                print(f"预训练模型已下载并保存到: {model_path}")
            except Exception as e:
                print(f"下载预训练模型失败: {e}")
                return None
        else:
            print(f"预训练模型已存在: {model_path}")
            model = YOLO(str(model_path))
        
        return model
    
    def train_model(self, model):
        """训练模型"""
        print("开始训练模型...")
        
        data_yaml_path = self.data_dir / "data.yaml"
        
        # 训练参数
        train_args = {
            'data': str(data_yaml_path),
            'epochs': self.epochs,
            'imgsz': self.imgsz,
            'batch': self.batch,
            'patience': self.patience,
            'save': True,
            'exist_ok': True,
            'project': str(self.model_dir),
            'name': 'train_results',
            'verbose': True
        }
        
        print(f"训练参数: {train_args}")
        
        try:
            # 开始训练
            results = model.train(**train_args)
            
            # 保存训练结果
            self.save_training_results(results, model)
            
            return results, model
            
        except Exception as e:
            print(f"训练过程中出现错误: {e}")
            return None, None
    
    def save_training_results(self, results, model):
        """保存训练结果和参数"""
        print("保存训练结果和参数...")
        
        results_dir = self.model_dir / "train_results"
        
        # 保存训练结果到JSON文件
        training_info = {
            'training_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'epochs': self.epochs,
            'image_size': self.imgsz,
            'batch_size': self.batch,
            'patience': self.patience,
            'model_name': self.pretrained_model
        }
        
        # 添加训练指标（如果可用）
        if hasattr(results, 'results_dict'):
            training_info.update(results.results_dict)
        
        # 保存训练信息
        info_path = results_dir / "training_info.json"
        with open(info_path, 'w', encoding='utf-8') as f:
            json.dump(training_info, f, indent=4, ensure_ascii=False)
        
        print(f"训练信息已保存: {info_path}")
        
        # 导出为ONNX格式
        self.export_to_onnx(model)
    
    def export_to_onnx(self, model):
        """将模型导出为ONNX格式"""
        print("导出模型为ONNX格式...")
        
        try:
            # 获取最佳模型路径
            best_model_path = self.model_dir / "train_results" / "weights" / "best.pt"
            
            if best_model_path.exists():
                # 加载最佳模型
                best_model = YOLO(str(best_model_path))
                
                # 导出为ONNX
                onnx_path = self.model_dir / "best_model.onnx"
                success = best_model.export(format='onnx', imgsz=self.imgsz, dynamic=True)
                
                if success:
                    print(f"ONNX模型已保存: {onnx_path}")
                    
                    # 复制到model目录
                    exported_onnx = self.model_dir / "train_results" / "weights" / "best.onnx"
                    if exported_onnx.exists():
                        shutil.copy2(exported_onnx, onnx_path)
                        print(f"ONNX模型已复制到: {onnx_path}")
                else:
                    print("ONNX导出失败")
            else:
                print("未找到最佳模型文件")
                
        except Exception as e:
            print(f"ONNX导出过程中出现错误: {e}")
    
    def print_training_summary(self, results):
        """打印训练结果摘要"""
        print("\n" + "="*50)
        print("训练完成摘要")
        print("="*50)
        
        if results and hasattr(results, 'results_dict'):
            metrics = results.results_dict
            print(f"训练轮次: {self.epochs}")
            print(f"图像尺寸: {self.imgsz}")
            print(f"批量大小: {self.batch}")
            
            if 'metrics/mAP50(B)' in metrics:
                print(f"mAP50: {metrics['metrics/mAP50(B)']:.4f}")
            if 'metrics/mAP50-95(B)' in metrics:
                print(f"mAP50-95: {metrics['metrics/mAP50-95(B)']:.4f}")
        
        print(f"模型文件位置: {self.model_dir}")
        print(f"ONNX模型: {self.model_dir / 'best_model.onnx'}")
        print("="*50)
    
    def run(self):
        """运行训练流程"""
        print("开始YOLOv8实例分割训练流程...")
        
        # 检查数据集结构
        if not self.check_data_structure():
            print("数据集结构检查失败，请按照data/README.md中的要求组织数据集")
            return
        
        # 创建data.yaml
        self.create_data_yaml()
        
        # 下载预训练模型
        model = self.download_pretrained_model()
        if model is None:
            print("预训练模型获取失败")
            return
        
        # 训练模型
        results, trained_model = self.train_model(model)
        
        if results is not None:
            # 打印训练摘要
            self.print_training_summary(results)
            print("训练流程完成！")
        else:
            print("训练失败")


if __name__ == "__main__":
    trainer = YOLOv8InstanceSegmentationTrainer()
    trainer.run()
