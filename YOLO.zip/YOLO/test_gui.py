#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于YOLOv8的个人实例分割系统GUI测试脚本
功能：
1. 提供图形界面选择测试图片
2. 加载训练好的模型进行实例分割
3. 显示分割结果和详细分析
4. 保存结果图像
"""

import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import cv2
import numpy as np
from ultralytics import YOLO
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import json
from datetime import datetime


class YOLOv8InstanceSegmentationGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("YOLOv8实例分割测试系统")
        self.root.geometry("1200x800")
        
        # 项目目录
        self.project_dir = Path(__file__).parent
        self.model_dir = self.project_dir / "model"
        self.results_dir = self.project_dir / "test_results"
        self.results_dir.mkdir(exist_ok=True)
        
        # 模型相关变量
        self.model = None
        self.current_image = None
        self.current_image_path = None
        self.results = None
        
        # 创建界面
        self.create_widgets()
        
        # 自动加载模型
        self.load_model_automatically()
    
    def create_widgets(self):
        """创建GUI组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(2, weight=1)
        
        # 标题
        title_label = ttk.Label(main_frame, text="YOLOv8实例分割测试系统", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # 控制面板
        control_frame = ttk.LabelFrame(main_frame, text="控制面板", padding="10")
        control_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 模型选择
        ttk.Label(control_frame, text="模型文件:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.model_var = tk.StringVar()
        self.model_combo = ttk.Combobox(control_frame, textvariable=self.model_var, width=50)
        self.model_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        self.model_combo['values'] = self.get_available_models()
        
        ttk.Button(control_frame, text="加载模型", 
                  command=self.load_model).grid(row=0, column=2, padx=(0, 10))
        
        # 图像选择
        ttk.Button(control_frame, text="选择图像", 
                  command=self.select_image).grid(row=1, column=0, pady=10)
        
        ttk.Button(control_frame, text="运行分割", 
                  command=self.run_segmentation).grid(row=1, column=1, pady=10)
        
        ttk.Button(control_frame, text="保存结果", 
                  command=self.save_results).grid(row=1, column=2, pady=10)
        
        # 置信度阈值
        ttk.Label(control_frame, text="置信度阈值:").grid(row=2, column=0, sticky=tk.W, padx=(0, 5))
        self.conf_var = tk.DoubleVar(value=0.25)
        conf_scale = ttk.Scale(control_frame, from_=0.1, to=0.9, 
                              variable=self.conf_var, orient=tk.HORIZONTAL)
        conf_scale.grid(row=2, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        self.conf_label = ttk.Label(control_frame, text="0.25")
        self.conf_label.grid(row=2, column=2)
        conf_scale.configure(command=self.update_conf_label)
        
        # 结果显示区域
        display_frame = ttk.Frame(main_frame)
        display_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 图像显示
        image_frame = ttk.LabelFrame(display_frame, text="图像显示", padding="10")
        image_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        self.image_label = ttk.Label(image_frame, text="请选择图像文件", 
                                    background="white", anchor=tk.CENTER)
        self.image_label.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 结果分析
        analysis_frame = ttk.LabelFrame(display_frame, text="结果分析", padding="10")
        analysis_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 创建文本区域显示结果
        self.result_text = tk.Text(analysis_frame, width=40, height=20, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(analysis_frame, orient=tk.VERTICAL, command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=scrollbar.set)
        self.result_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # 配置权重
        display_frame.columnconfigure(0, weight=2)
        display_frame.columnconfigure(1, weight=1)
        display_frame.rowconfigure(0, weight=1)
        image_frame.columnconfigure(0, weight=1)
        image_frame.rowconfigure(0, weight=1)
        analysis_frame.columnconfigure(0, weight=1)
        analysis_frame.rowconfigure(0, weight=1)
    
    def update_conf_label(self, value):
        """更新置信度阈值标签"""
        self.conf_label.config(text=f"{float(value):.2f}")
    
    def get_available_models(self):
        """获取可用的模型文件"""
        models = []
        if self.model_dir.exists():
            # 查找ONNX模型
            onnx_models = list(self.model_dir.glob("*.onnx"))
            # 查找PyTorch模型
            pt_models = list(self.model_dir.glob("*.pt"))
            
            models = [str(model) for model in onnx_models + pt_models]
        
        return models
    
    def load_model_automatically(self):
        """自动加载模型"""
        available_models = self.get_available_models()
        if available_models:
            # 优先选择ONNX模型
            onnx_models = [m for m in available_models if m.endswith('.onnx')]
            if onnx_models:
                self.model_var.set(onnx_models[0])
            else:
                self.model_var.set(available_models[0])
            self.load_model()
    
    def load_model(self):
        """加载选择的模型"""
        model_path = self.model_var.get()
        if not model_path:
            messagebox.showerror("错误", "请选择模型文件")
            return
        
        try:
            self.model = YOLO(model_path)
            messagebox.showinfo("成功", f"模型加载成功: {Path(model_path).name}")
            self.update_result_text("模型加载完成，请选择图像进行测试。")
        except Exception as e:
            messagebox.showerror("错误", f"模型加载失败: {str(e)}")
    
    def select_image(self):
        """选择测试图像"""
        file_path = filedialog.askopenfilename(
            title="选择测试图像",
            filetypes=[
                ("图像文件", "*.jpg *.jpeg *.png *.bmp"),
                ("所有文件", "*.*")
            ]
        )
        
        if file_path:
            self.current_image_path = file_path
            self.display_image(file_path)
            self.update_result_text(f"已选择图像: {Path(file_path).name}")
    
    def display_image(self, image_path):
        """显示图像"""
        try:
            # 打开图像
            image = Image.open(image_path)
            
            # 调整大小以适应显示区域
            max_size = (600, 400)
            image.thumbnail(max_size, Image.Resampling.LANCZOS)
            
            # 转换为PhotoImage
            photo = ImageTk.PhotoImage(image)
            
            # 更新标签
            self.image_label.configure(image=photo)
            self.image_label.image = photo  # 保持引用
            
            self.current_image = image
            
        except Exception as e:
            messagebox.showerror("错误", f"图像加载失败: {str(e)}")
    
    def run_segmentation(self):
        """运行实例分割"""
        if self.model is None:
            messagebox.showerror("错误", "请先加载模型")
            return
        
        if self.current_image_path is None:
            messagebox.showerror("错误", "请先选择图像")
            return
        
        try:
            # 运行分割
            conf_threshold = self.conf_var.get()
            results = self.model.predict(
                source=self.current_image_path,
                conf=conf_threshold,
                save=False,
                show=False
            )
            
            self.results = results[0]  # 取第一个结果
            
            # 显示结果
            self.display_results()
            
        except Exception as e:
            messagebox.showerror("错误", f"分割失败: {str(e)}")
    
    def display_results(self):
        """显示分割结果"""
        if self.results is None:
            return
        
        # 获取原始图像
        original_image = cv2.imread(self.current_image_path)
        original_image = cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB)
        
        # 绘制分割结果
        result_image = self.results.plot()
        
        # 显示结果图像
        result_pil = Image.fromarray(result_image)
        max_size = (600, 400)
        result_pil.thumbnail(max_size, Image.Resampling.LANCZOS)
        result_photo = ImageTk.PhotoImage(result_pil)
        
        self.image_label.configure(image=result_photo)
        self.image_label.image = result_photo
        
        # 更新结果分析
        self.update_analysis()
    
    def update_analysis(self):
        """更新结果分析"""
        if self.results is None:
            return
        
        analysis_text = "=== 实例分割结果分析 ===\n\n"
        
        # 检测到的实例数量
        if hasattr(self.results, 'boxes') and self.results.boxes is not None:
            num_instances = len(self.results.boxes)
            analysis_text += f"检测到的实例数量: {num_instances}\n\n"
        else:
            analysis_text += "未检测到任何实例\n\n"
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(1.0, analysis_text)
            return
        
        # 详细信息
        analysis_text += "实例详细信息:\n"
        analysis_text += "-" * 40 + "\n"
        
        if hasattr(self.results, 'boxes') and self.results.boxes is not None:
            boxes = self.results.boxes
            for i, (box, conf, cls) in enumerate(zip(boxes.xyxy, boxes.conf, boxes.cls)):
                analysis_text += f"实例 {i+1}:\n"
                analysis_text += f"  类别: {self.results.names[int(cls)]}\n"
                analysis_text += f"  置信度: {conf:.4f}\n"
                analysis_text += f"  边界框: [{box[0]:.1f}, {box[1]:.1f}, {box[2]:.1f}, {box[3]:.1f}]\n"
                analysis_text += "\n"
        
        # 分割掩码信息
        if hasattr(self.results, 'masks') and self.results.masks is not None:
            analysis_text += "分割掩码信息:\n"
            analysis_text += f"  掩码数量: {len(self.results.masks)}\n"
            analysis_text += f"  掩码形状: {self.results.masks.data.shape}\n\n"
        
        # 性能统计
        if hasattr(self.results, 'speed'):
            speed = self.results.speed
            analysis_text += "性能统计:\n"
            analysis_text += f"  预处理时间: {speed.get('preprocess', 0):.1f} ms\n"
            analysis_text += f"  推理时间: {speed.get('inference', 0):.1f} ms\n"
            analysis_text += f"  后处理时间: {speed.get('postprocess', 0):.1f} ms\n"
        
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(1.0, analysis_text)
    
    def update_result_text(self, text):
        """更新结果文本框"""
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(1.0, text)
    
    def save_results(self):
        """保存结果"""
        if self.results is None:
            messagebox.showerror("错误", "没有可保存的结果")
            return
        
        try:
            # 生成文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_name = Path(self.current_image_path).stem
            
            # 保存结果图像
            result_image_path = self.results_dir / f"{base_name}_result_{timestamp}.jpg"
            result_image = self.results.plot()
            cv2.imwrite(str(result_image_path), cv2.cvtColor(result_image, cv2.COLOR_RGB2BGR))
            
            # 保存分析结果
            analysis_path = self.results_dir / f"{base_name}_analysis_{timestamp}.txt"
            analysis_text = self.result_text.get(1.0, tk.END)
            with open(analysis_path, 'w', encoding='utf-8') as f:
                f.write(analysis_text)
            
            # 保存JSON格式的详细结果
            json_path = self.results_dir / f"{base_name}_details_{timestamp}.json"
            details = {
                'timestamp': timestamp,
                'image_path': str(self.current_image_path),
                'model_path': self.model_var.get(),
                'confidence_threshold': self.conf_var.get(),
                'detections': []
            }
            
            if hasattr(self.results, 'boxes') and self.results.boxes is not None:
                boxes = self.results.boxes
                for i, (box, conf, cls) in enumerate(zip(boxes.xyxy, boxes.conf, boxes.cls)):
                    detection = {
                        'instance_id': i + 1,
                        'class_name': self.results.names[int(cls)],
                        'class_id': int(cls),
                        'confidence': float(conf),
                        'bbox': [float(box[0]), float(box[1]), float(box[2]), float(box[3])]
                    }
                    details['detections'].append(detection)
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(details, f, indent=2, ensure_ascii=False)
            
            messagebox.showinfo("成功", 
                              f"结果已保存:\n"
                              f"图像: {result_image_path.name}\n"
                              f"分析: {analysis_path.name}\n"
                              f"详情: {json_path.name}")
            
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {str(e)}")


def main():
    root = tk.Tk()
    app = YOLOv8InstanceSegmentationGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
